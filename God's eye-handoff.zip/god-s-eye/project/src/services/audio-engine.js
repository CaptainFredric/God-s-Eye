/**
 * God's Eye — Dynamic Audio Engine v2
 *
 * Redesigned for a calmer, more cinematic feel.
 * All sounds are Web Audio API synthesised — no external files.
 *
 *   sfx.ping()        — deep sonar sweep
 *   sfx.click()       — soft tactile tap
 *   sfx.zoom()        — gentle orbital whoosh
 *   sfx.alert()       — low, two-note pulse (not a klaxon)
 *   sfx.notify()      — warm glass-chime notification
 *   sfx.type()        — whisper keystroke
 *   sfx.panelOpen()   — airy ascending breath
 *   sfx.panelClose()  — soft descending breath
 *   sfx.toggleOn()    — subtle bright tick
 *   sfx.toggleOff()   — subtle dim tick
 *   sfx.success()     — warm chord bloom
 *   sfx.zoomTick()    — micro scroll click
 *   sfx.startAmbient()
 *   sfx.stopAmbient()
 */

const STORAGE_KEY = "panopticon-earth-audio-enabled";

let ctx = null;
let masterGain = null;
let ambientNodes = null;
let _enabled = false;
let _ready = false;

function getEnabled() {
  try { return localStorage.getItem(STORAGE_KEY) !== "0"; } catch { return true; }
}

function setEnabled(v) {
  _enabled = v;
  try { localStorage.setItem(STORAGE_KEY, v ? "1" : "0"); } catch { /* */ }
  if (masterGain) masterGain.gain.setTargetAtTime(v ? 1 : 0, ctx.currentTime, 0.08);
}

function initAudioEngine() {
  if (_ready) return;
  try {
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    masterGain = ctx.createGain();
    masterGain.connect(ctx.destination);
    _enabled = getEnabled();
    masterGain.gain.value = _enabled ? 1 : 0;
    _ready = true;
  } catch {
    _ready = false;
  }
}

function ensureCtx() {
  if (!_ready) initAudioEngine();
  if (ctx?.state === "suspended") ctx.resume().catch(() => {});
  return _ready && _enabled;
}

// ── Ambient Hum — deep space low drone ───────────────────────────────────

function startAmbient() {
  if (!ensureCtx() || ambientNodes) return;
  const now = ctx.currentTime;

  // Primary drone — low and warm
  const osc1 = ctx.createOscillator();
  osc1.type = "sine";
  osc1.frequency.value = 55; // A1 — deep and calm
  const g1 = ctx.createGain();
  g1.gain.value = 0;
  g1.gain.linearRampToValueAtTime(0.04, now + 4);
  osc1.connect(g1).connect(masterGain);
  osc1.start(now);

  // Soft upper harmonic for texture
  const osc2 = ctx.createOscillator();
  osc2.type = "sine";
  osc2.frequency.value = 110; // A2
  const g2 = ctx.createGain();
  g2.gain.value = 0;
  g2.gain.linearRampToValueAtTime(0.015, now + 5);
  osc2.connect(g2).connect(masterGain);
  osc2.start(now);

  // Very slow tremolo
  const lfo = ctx.createOscillator();
  lfo.type = "sine";
  lfo.frequency.value = 0.07;
  const lfoGain = ctx.createGain();
  lfoGain.gain.value = 3;
  lfo.connect(lfoGain).connect(osc1.frequency);
  lfo.start(now);

  ambientNodes = { osc1, osc2, lfo, g1, g2, lfoGain };
}

function stopAmbient() {
  if (!ambientNodes || !ctx) return;
  const now = ctx.currentTime;
  ambientNodes.g1.gain.linearRampToValueAtTime(0, now + 2);
  ambientNodes.g2.gain.linearRampToValueAtTime(0, now + 2);
  setTimeout(() => {
    try {
      ambientNodes.osc1.stop();
      ambientNodes.osc2.stop();
      ambientNodes.lfo.stop();
    } catch { /* */ }
    ambientNodes = null;
  }, 2500);
}

// ── Deep Sonar Ping — slow descending sweep ──────────────────────────────

function ping() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;

  // Main tone: warm sine sweep downward (submarine sonar feel)
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(660, now);
  osc.frequency.exponentialRampToValueAtTime(220, now + 0.6);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.09, now);
  g.gain.exponentialRampToValueAtTime(0.001, now + 0.7);

  // Subtle reverb tail using delay+feedback
  const delay = ctx.createDelay(0.5);
  delay.delayTime.value = 0.22;
  const fbGain = ctx.createGain();
  fbGain.gain.value = 0.28;
  delay.connect(fbGain).connect(delay);
  delay.connect(masterGain);

  osc.connect(g);
  g.connect(masterGain);
  g.connect(delay);
  osc.start(now);
  osc.stop(now + 0.75);
}

// ── Soft Tactile Click ───────────────────────────────────────────────────

function click() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;
  const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.025), ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) {
    data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (data.length * 0.1));
  }
  const src = ctx.createBufferSource();
  src.buffer = buf;

  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = 1800; // softer than before (was 3500)
  bp.Q.value = 1.8;

  const g = ctx.createGain();
  g.gain.setValueAtTime(0.10, now); // quieter than before (was 0.18)
  g.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

  src.connect(bp).connect(g).connect(masterGain);
  src.start(now);
}

// ── Orbital Whoosh — gentle, smooth ─────────────────────────────────────

function zoom() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;
  const dur = 1.4;

  // Smooth noise swoosh
  const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const src = ctx.createBufferSource();
  src.buffer = buf;

  const lp = ctx.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.setValueAtTime(300, now);
  lp.frequency.exponentialRampToValueAtTime(2400, now + dur * 0.5);
  lp.frequency.exponentialRampToValueAtTime(400, now + dur);

  const g = ctx.createGain();
  g.gain.setValueAtTime(0, now);
  g.gain.linearRampToValueAtTime(0.055, now + dur * 0.4);
  g.gain.linearRampToValueAtTime(0, now + dur);

  src.connect(lp).connect(g).connect(masterGain);
  src.start(now);
  src.stop(now + dur + 0.1);

  // Very subtle tonal shimmer
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(180, now);
  osc.frequency.exponentialRampToValueAtTime(440, now + dur * 0.55);
  osc.frequency.exponentialRampToValueAtTime(220, now + dur);
  const gOsc = ctx.createGain();
  gOsc.gain.setValueAtTime(0, now);
  gOsc.gain.linearRampToValueAtTime(0.018, now + dur * 0.4);
  gOsc.gain.linearRampToValueAtTime(0, now + dur);
  osc.connect(gOsc).connect(masterGain);
  osc.start(now);
  osc.stop(now + dur + 0.1);
}

// ── Alert — calm low two-note pulse (not a klaxon) ───────────────────────

function alert() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;

  // Two low sine pulses — D3 then A2 — calm and measured
  [[293, 0], [220, 0.45]].forEach(([freq, offset]) => {
    const t = now + offset;
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.07, t + 0.04);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.38);
    osc.connect(g).connect(masterGain);
    osc.start(t);
    osc.stop(t + 0.42);
  });
}

// ── Terminal Keystroke — very quiet whisper ───────────────────────────────

function typeKey() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;
  const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.012), ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) {
    data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (data.length * 0.18));
  }
  const src = ctx.createBufferSource();
  src.buffer = buf;

  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.value = 1400;

  const g = ctx.createGain();
  g.gain.setValueAtTime(0.055, now);
  g.gain.exponentialRampToValueAtTime(0.001, now + 0.02);

  src.connect(hp).connect(g).connect(masterGain);
  src.start(now);
}

// ── Panel Open — airy ascending breath ───────────────────────────────────

function panelOpen() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;

  // Breathy noise swell
  const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.22), ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.setValueAtTime(600, now);
  hp.frequency.exponentialRampToValueAtTime(3000, now + 0.22);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0, now);
  g.gain.linearRampToValueAtTime(0.055, now + 0.09);
  g.gain.linearRampToValueAtTime(0, now + 0.22);
  src.connect(hp).connect(g).connect(masterGain);
  src.start(now);

  // Soft tonal tail
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(440, now);
  osc.frequency.exponentialRampToValueAtTime(660, now + 0.14);
  const gOsc = ctx.createGain();
  gOsc.gain.setValueAtTime(0.04, now);
  gOsc.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
  osc.connect(gOsc).connect(masterGain);
  osc.start(now);
  osc.stop(now + 0.22);
}

// ── Panel Close — soft descending breath ─────────────────────────────────

function panelClose() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(660, now);
  osc.frequency.exponentialRampToValueAtTime(330, now + 0.16);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.04, now);
  g.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
  osc.connect(g).connect(masterGain);
  osc.start(now);
  osc.stop(now + 0.2);
}

// ── Toggle On — precise bright tick ──────────────────────────────────────

function toggleOn() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(1047, now); // C6
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.055, now);
  g.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
  osc.connect(g).connect(masterGain);
  osc.start(now);
  osc.stop(now + 0.09);
}

// ── Toggle Off — dim tick ─────────────────────────────────────────────────

function toggleOff() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(660, now); // E5
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.045, now);
  g.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
  osc.connect(g).connect(masterGain);
  osc.start(now);
  osc.stop(now + 0.09);
}

// ── Notify — warm glass-chime (replaces klaxon-like two-tone) ────────────
//   Plays a soft E4 → G#4 chime with a gentle shimmer tail.

function notify() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;
  const notes = [329.63, 415.30]; // E4, G#4 — warm, resolving interval
  notes.forEach((freq, i) => {
    const t = now + i * 0.11;
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq;

    // Second harmonic for glassy texture
    const osc2 = ctx.createOscillator();
    osc2.type = "sine";
    osc2.frequency.value = freq * 2;
    const g2 = ctx.createGain();
    g2.gain.setValueAtTime(0.012, t);
    g2.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    osc2.connect(g2).connect(masterGain);
    osc2.start(t);
    osc2.stop(t + 0.32);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.05, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
    osc.connect(g).connect(masterGain);
    osc.start(t);
    osc.stop(t + 0.48);
  });
}

// ── Success — warm major chord bloom ─────────────────────────────────────

function success() {
  if (!ensureCtx()) return;
  const now = ctx.currentTime;
  [261.63, 329.63, 392.00].forEach((freq, i) => { // C4 E4 G4 — major triad
    const t = now + i * 0.06;
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.045, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
    osc.connect(g).connect(masterGain);
    osc.start(t);
    osc.stop(t + 0.52);
  });
}

// ── Zoom Tick — micro scroll click ───────────────────────────────────────

let _lastZoomTick = 0;
function zoomTick() {
  if (!ensureCtx()) return;
  const now = performance.now();
  if (now - _lastZoomTick < 120) return;
  _lastZoomTick = now;
  const t = ctx.currentTime;
  const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.016), ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) {
    data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (data.length * 0.12));
  }
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = 2000;
  bp.Q.value = 1.2;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.028, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + 0.025);
  src.connect(bp).connect(g).connect(masterGain);
  src.start(t);
}

// ── Public API ───────────────────────────────────────────────────────────

export const sfx = {
  ping,
  click,
  zoom,
  alert,
  type: typeKey,
  panelOpen,
  panelClose,
  toggleOn,
  toggleOff,
  notify,
  success,
  zoomTick,
  startAmbient,
  stopAmbient
};

export { initAudioEngine, setEnabled as setAudioEnabled, getEnabled as isAudioEnabled };
